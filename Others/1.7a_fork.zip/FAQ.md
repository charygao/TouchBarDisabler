## If you're unable to open TouchBarDisabler

If you see the following alert:
![](https://raw.githubusercontent.com/HiKay/macOSLucidaGrande/master/Screenshot/guide-alert.png "GateKeeper Alert")

Right click on the downloaded TouchBarDisabler app and click "Open".
![](https://raw.githubusercontent.com/HiKay/macOSLucidaGrande/master/Screenshot/guide-open1.png "Choosing to Open TouchBarDisabler app")

Then click "Open" again.
![](https://raw.githubusercontent.com/HiKay/macOSLucidaGrande/master/Screenshot/guide-open2.png "Confirm and Open TouchBarDisabler app")
