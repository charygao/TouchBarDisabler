//
//  AppDelegate.h
//  TouchBarDisabler Helper
//
//  Created by Bright on 7/20/17.
//
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

