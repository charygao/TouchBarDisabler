//
//  ViewController.h
//  TouchBarDisabler Helper
//
//  Created by Bright on 7/20/17.
//
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

