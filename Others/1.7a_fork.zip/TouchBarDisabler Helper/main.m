//
//  main.m
//  TouchBarDisabler Helper
//
//  Created by Bright on 7/20/17.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
